#pragma once
#include <Windows.h>
#include "includes.h"
#include "mem.h"
#include <corecrt_math.h>
#include <intrin.h>


struct view_matrix_t
{
	float* operator[](int index)
	{
		return matrix[index];
	}

	float matrix[4][4];
};

typedef struct
{
	float matrix[3][4];
} Matrix3x4_T;

struct Vector3
{
	float x, y, z;
};

Vector3 WorldToScreen(const Vector3 pos, view_matrix_t matrix)
{


	float x_ = matrix[0][0] * pos.x + matrix[0][1] * pos.y + matrix[0][2] * pos.z + matrix[0][3];

	


	float y_ = matrix[1][0] * pos.x + matrix[1][1] * pos.y + matrix[1][2] * pos.z + matrix[1][3];

	

	float w_ = matrix[3][0] * pos.x + matrix[3][1] * pos.y + matrix[3][2] * pos.z + matrix[3][3];

	


	float inv_w = 1.f / w_;
	x_ *= inv_w;
	y_ *= inv_w;


	float x = pGlobals.screenX * .5f;
	float y = pGlobals.screenY * .5f;

	x += 0.5f * x_ * pGlobals.screenX + 0.5f;
	y -= 0.5f * y_ * pGlobals.screenY + 0.5f;

	return { x,y, w_ };
}

Vector3	getEntBonePos(DWORD playerBase, int boneID)
{
	Matrix3x4_T bone = RPM<Matrix3x4_T>(playerBase + offsets::m_dwBoneMatrix + boneID * 0x30);

	return{
		bone.matrix[0][3],
		bone.matrix[1][3],
		bone.matrix[2][3]
	};
}